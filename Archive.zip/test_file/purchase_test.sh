CUDA_VISIBLE_DEVICES=0 python3 purchase_test.py --dataset purchase --target_learning_rate 0.001 --target_epochs 100 --target_batch_size 100
