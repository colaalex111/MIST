CUDA_VISIBLE_DEVICES=0 python3 texas_test.py --dataset texas --target_learning_rate 0.001 --target_epochs 100 --target_batch_size 100
