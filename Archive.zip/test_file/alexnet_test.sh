CUDA_VISIBLE_DEVICES=0 python3 alexnet_test.py --mixup 0 --dataset cifar10 --target_learning_rate 0.01 --target_epochs 160 --target_batch_size 128
