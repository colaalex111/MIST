CUDA_VISIBLE_DEVICES=2 python3 wildresnet_test.py --dataset cifar10 --target_learning_rate 0.1 --target_epochs 200 --target_batch_size 128
