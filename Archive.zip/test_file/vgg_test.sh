CUDA_VISIBLE_DEVICES=2 python3 vgg_test.py --dataset cifar100 --target_learning_rate 0.01 --target_epochs 160 --schedule 80 120 --target_batch_size 128
