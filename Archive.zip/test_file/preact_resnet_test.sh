CUDA_VISIBLE_DEVICES=2 python3 preact_resnet_test.py --dataset cifar10 --target_learning_rate 0.01 --target_epochs 200 --target_batch_size 128
